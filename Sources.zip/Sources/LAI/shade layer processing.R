library(ncdf4) 
library(raster) 
library(rgdal)
require(GeoLight)

## NEOTROPICAL MAP

dir <- "C:/Users/Juanvigr/Dropbox/Marie Curie/Modeling impacts of deforestation/Sources"
shapeTotal <- raster(paste0(dir,"/bio1.bil"))

resolution = 1 # Set resolution (deg)

world <- aggregate(shapeTotal, fact=resolution/res(shapeTotal)[1]) 

tropical_forest <- shapefile(paste0(dir,"/Shapes/htrop.shp"))
tropical_forest <- aggregate(rbind(tropical_forest))
# tropical_forest <- shapefile(paste0(dir,"/Shapes/amazon_sensulatissimo_gmm_v1.shp"))

Amazonia_map <- mask(world, tropical_forest)
Amazonia_map <- crop(Amazonia_map, c(-100, -30, -40, 30))  # Extent

plot(Amazonia_map)

xy <- xyFromCell(Amazonia_map, 1:ncell(Amazonia_map))
cells <- cellFromPolygon(Amazonia_map, tropical_forest)[[1]]
xy.values <- xy[cells,]
nrow(xy.values)

## Load LAI data for shade estimations

nc_data <- nc_open(paste0(dir,"/LAI/LAI_mean_monthly_1981-2015.nc4"))
lon <- ncvar_get(nc_data, "lon")
lat <- ncvar_get(nc_data, "lat", verbose = F)
t <- ncvar_get(nc_data, "time")
lai.array <- ncvar_get(nc_data, "LAI")
dim(lai.array)

# Transform LAI into dataset to make everything faster (monthly averages)

LAI_matrix <- array(NA, dim=c(nrow(xy.values), 14))
for(month in 1:12){
  for(cell in 1:nrow(xy.values)){
    # extract LAI from layer
    if(month>=8){m=month-7}else{m=month+5} # 1: aug, 2:sept....
    lai.slice <- lai.array[, , m]
    r <- raster(t(lai.slice), xmn=min(lon), xmx=max(lon), ymn=min(lat), ymx=max(lat), crs=CRS("+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"))
    r <- flip(r, direction='y')
    r <- aggregate(r, fact=resolution/res(r)[1])
    LAI <- extract(r, cellFromXY(r, xy.values[cell,]))
    
    LAI_matrix[cell,month] <- LAI 
    
    print(paste0(round(100*cell/nrow(xy.values)), " % ", "month ", month))
  }
}
LAI_matrix[,13:14] <- xy.values
save(LAI_matrix, file=paste0(dir,"/LAI/LAI_matrix_0.5x0.5.RData"))

# only one month

month = 7

LAI_matrix_july <- numeric(nrow(xy.values))

for(cell in 1:nrow(xy.values)){
  # extract LAI from layer
  if(month>=8){m=month-7}else{m=month+5} # 1: aug, 2:sept....
  lai.slice <- lai.array[, , m]
  r <- raster(t(lai.slice), xmn=min(lon), xmx=max(lon), ymn=min(lat), ymx=max(lat), crs=CRS("+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"))
  r <- flip(r, direction='y')
  r <- aggregate(r, fact=resolution/res(r)[1])
  LAI <- raster::extract(r, cellFromXY(r, xy.values[cell,]))
  
  LAI_matrix_july[cell] <- LAI 
  
  print(paste0(round(100*cell/nrow(xy.values), 2), " % ", "month ", month))
}

# save(LAI_matrix_july, file=paste0(dir,"/LAI/LAI_matrix_july_tropical_forest_HD.RData"))

require(ggplot2)
ggplot() + geom_tile(mapping=aes(x=xy.values[,1], y=xy.values[,2], fill=LAI_matrix_july))

